<?php
namespace Embitel\Graphql\Api;
/**
 * @api
 */
interface CustomInterface
{
    /**
     * 
     * get Name
     * @return array
     */

    public function getData();

     /**
     * get name
     * 
     * @param string[] $data
     * @return array
     */

     public function createCustomergroup($data);

}
    ?>

 
